class Bidule():
    def __init__(self, machin):
        self.machin = machin

    def getMachin(self):
        return self.machin

    def __str__(self) -> str:
        return self.machin
